//
//  NSDictionary+CrashNilSafe.h
//  NilSafeTest
//
//  Created by mac on 2019/9/27.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

@interface NSDictionary (CrashNilSafe)

@end

@interface NSMutableDictionary (CrashNilSafe)

@end

NS_ASSUME_NONNULL_END
