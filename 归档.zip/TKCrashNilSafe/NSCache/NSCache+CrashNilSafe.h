//
//  NSCache+CrashNilSafe.h
//  NilSafeTest
//
//  Created by mac on 2019/10/15.
//  Copyright © 2019 mac. All rights reserved.
//

#import <Foundation/Foundation.h>



NS_ASSUME_NONNULL_BEGIN

@interface NSCache (CrashNilSafe)

@end

NS_ASSUME_NONNULL_END
