//
//  NSJSONSerialization+TKCrashNilSafe.h
//  NilSafeTest
//
//  Created by PC on 2021/3/20.
//  Copyright © 2021 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSJSONSerialization (TKCrashNilSafe)

@end

NS_ASSUME_NONNULL_END
